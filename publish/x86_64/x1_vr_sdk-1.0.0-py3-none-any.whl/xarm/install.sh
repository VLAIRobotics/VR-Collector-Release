#!/bin/bash
set -e

echo "==> 检查操作系统"
if [[ "$(uname -s)" != "Linux" ]]; then echo "❌ 仅支持 Linux"; exit 1; fi
OS_VER=$(lsb_release -rs 2>/dev/null || grep VERSION_ID /etc/os-release | cut -d= -f2 | tr -d '"')
if [[ "$OS_VER" != "22.04" && "$OS_VER" != "24.04" ]]; then
    echo "⚠️  脚本仅在 Ubuntu 22.04 / 24.04 测试过（当前：$OS_VER），是否继续？[y/N]"
    read -n1 -r; echo; [[ $REPLY =~ ^[Yy]$ ]] || exit 1
fi
echo "    Ubuntu $OS_VER ✓"

echo "==> 检查 conda 环境"
if [[ -z "$CONDA_DEFAULT_ENV" ]]; then
    echo "❌ 请先激活一个 conda 环境（conda activate <env>）再运行本脚本"; exit 1
fi
echo "    conda env: $CONDA_DEFAULT_ENV ✓"

echo "==> 安装系统依赖"
sudo apt install -y can-utils

echo "==> 加载 CAN 驱动（PEAK PCAN-USB FD）"
sudo modprobe peak_usb
echo "peak_usb" | sudo tee /etc/modules-load.d/peak_usb.conf > /dev/null
echo "    peak_usb 已加载并设置开机自动加载 ✓"

echo "==> 安装 conda 依赖"
conda install -c conda-forge libstdcxx-ng -y
conda install pip -y
pip install --upgrade pip

echo "==> 安装 pip 依赖"
pip install numpy scipy mujoco meshcat mink loop_rate_limiters osqp lerobot typeguard pyyaml

echo "==> 安装 xrobotoolkit_sdk"
TMPDIR=$(mktemp -d)
git clone https://github.com/XR-Robotics/XRoboToolkit-PC-Service-Pybind.git "$TMPDIR/XRoboToolkit-PC-Service-Pybind"
cd "$TMPDIR/XRoboToolkit-PC-Service-Pybind"
bash setup_ubuntu.sh
cd - > /dev/null
rm -rf "$TMPDIR"

echo ""
echo "✅ 依赖安装完成"
echo ""
echo "使用方法："
echo "    source /opt/ros/humble/setup.bash   # 每次新终端执行"
echo "    xarm check  --config my_config.yaml"
echo "    xarm collect --config my_config.yaml"
