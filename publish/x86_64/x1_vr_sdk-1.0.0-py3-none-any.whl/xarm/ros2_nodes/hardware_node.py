import os
import sys
import argparse
import yaml
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

import rclpy
from xarm._hardware.interface import DualArmController


def _load_config(path):
    with open(os.path.expanduser(path)) as f:
        return yaml.safe_load(f)


def main():
    parser = argparse.ArgumentParser(description="XArm hardware control node")
    parser.add_argument("--left-can",  default=None, help="Left arm CAN interface")
    parser.add_argument("--right-can", default=None, help="Right arm CAN interface")
    parser.add_argument("--config",    default=None, help="Path to config yaml")
    args = parser.parse_args()

    left_can  = args.left_can  or "can3"
    right_can = args.right_can or "can2"
    kwargs    = {}

    if args.config:
        cfg   = _load_config(args.config)
        robot = cfg.get("robot", {})
        if args.left_can  is None: left_can  = robot.get("left_can",  left_can)
        if args.right_can is None: right_can = robot.get("right_can", right_can)
        if "kp"                  in robot: kwargs["kp"]               = robot["kp"]
        if "kd"                  in robot: kwargs["kd"]               = robot["kd"]
        if "init_joint_pos_left" in robot: kwargs["init_left_pose"]   = robot["init_joint_pos_left"]
        if "init_joint_pos_right"in robot: kwargs["init_right_pose"]  = robot["init_joint_pos_right"]
        if "gripper_open"        in robot: kwargs["gripper_open"]     = robot["gripper_open"]
        if "gripper_close"       in robot: kwargs["gripper_close"]    = robot["gripper_close"]
        if "control_rate_hz"     in robot: kwargs["control_rate_hz"]  = robot["control_rate_hz"]

    rclpy.init()
    node = DualArmController(left_can=left_can, right_can=right_can, **kwargs)
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("⌨️ Ctrl+C detected")
    finally:
        node.disable_all_motors()
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
