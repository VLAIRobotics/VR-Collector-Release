import os
import sys
import argparse
import yaml
import numpy as np
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

from xarm._teleop.mujoco_ik import XarmMujocoTeleopController
from xarm._utils.geometry import R_HEADSET_TO_WORLD

ASSETS_DIR = os.path.join(os.path.dirname(__file__), "..", "assets", "xarm")

manipulator_config = {
    "left": {
        "pose_source":     "left_controller",
        "control_trigger": "left_grip",
        "link_name":       "xarm_left_hand_tcp",
        "vis_target":      "left_target",
        "control_mode":    "pose",
        "gripper_config": {
            "type":            "parallel",
            "gripper_trigger": "left_trigger",
            "joint_names":     ["xarm_left_finger_joint1", "xarm_left_finger_joint2"],
            "open_pos":        [0.0, 0.0],
            "close_pos":       [0.044, 0.044],
        },
    },
    "right": {
        "pose_source":     "right_controller",
        "control_trigger": "right_grip",
        "link_name":       "xarm_right_hand_tcp",
        "vis_target":      "right_target",
        "control_mode":    "pose",
        "gripper_config": {
            "type":            "parallel",
            "gripper_trigger": "right_trigger",
            "joint_names":     ["xarm_right_finger_joint1", "xarm_right_finger_joint2"],
            "open_pos":        [0.0, 0.0],
            "close_pos":       [0.044, 0.044],
        },
    },
    "head": {
        "pose_source": "headset",
        "vis_target":  "headset",
    },
}


def _load_config(path):
    with open(os.path.expanduser(path)) as f:
        return yaml.safe_load(f)


def main():
    parser = argparse.ArgumentParser(description="XArm VR teleoperation node")
    parser.add_argument("--filter-alpha", type=float, default=None,
                        help="EMA filter coefficient for VR input (0~1)")
    parser.add_argument("--scale-factor",  type=float, default=None,
                        help="VR controller displacement scale factor")
    parser.add_argument("--config",        default=None, help="Path to config yaml")
    args = parser.parse_args()

    filter_alpha       = args.filter_alpha if args.filter_alpha is not None else 0.5
    scale_factor       = args.scale_factor if args.scale_factor is not None else 1.0
    reset_duration_sec = 3.0
    gripper_open       = -1.1
    gripper_close      = 0.0
    mj_qpos_init       = None

    if args.config:
        cfg   = _load_config(args.config)
        robot  = cfg.get("robot",  {})
        teleop = cfg.get("teleop", {})
        if args.filter_alpha is None:
            filter_alpha = teleop.get("filter_alpha", filter_alpha)
        if args.scale_factor is None:
            scale_factor = teleop.get("scale_factor", scale_factor)
        reset_duration_sec = teleop.get("reset_duration_sec", reset_duration_sec)
        gripper_open       = robot.get("gripper_open",        gripper_open)
        gripper_close      = robot.get("gripper_close",       gripper_close)
        if "init_joint_pos_left" in robot and "init_joint_pos_right" in robot:
            left_7  = robot["init_joint_pos_left"]
            right_7 = robot["init_joint_pos_right"]
            # MuJoCo qpos: left 7 joints + 2 fingers + right 7 joints + 2 fingers
            mj_qpos_init = np.array(left_7 + [0.0, 0.0] + right_7 + [0.0, 0.0])

    xml_path   = os.path.join(ASSETS_DIR, "scene.xml")
    controller = XarmMujocoTeleopController(
        xml_path           = xml_path,
        manipulator_config = manipulator_config,
        scale_factor       = scale_factor,
        filter_alpha       = filter_alpha,
        reset_duration_sec = reset_duration_sec,
        gripper_open       = gripper_open,
        gripper_close      = gripper_close,
        mj_qpos_init       = mj_qpos_init,
    )
    controller.run_dual_threaded()


if __name__ == "__main__":
    main()
