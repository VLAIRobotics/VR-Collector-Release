import os
import sys
# 离线数据采集：禁止 lerobot/huggingface_hub 访问网络（必须在导入 lerobot 之前设置）
os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
# 把 xarm_sdk/ 加进搜索路径，使 xarm 包可被导入（无论从哪个目录启动）
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

import argparse
import rclpy
from xarm._collection.recorder import XArmRecorder


def main():
    parser = argparse.ArgumentParser(description='XArm LeRobot Data Collector')
    parser.add_argument('--repo-id',           type=str, required=True)
    parser.add_argument('--root',              type=str, default='~/lerobot_datasets')
    parser.add_argument('--fps',               type=int, default=30)
    parser.add_argument('--arm-side',          type=str, default='dual_arm',
                        choices=['right_arm', 'left_arm', 'dual_arm'])
    parser.add_argument('--single-task',       type=str, default='default_task')
    parser.add_argument('--num-episodes',      type=int, default=50)
    parser.add_argument('--use-wrist-camera',  action='store_true', default=False)
    parser.add_argument('--no-chest-camera',   dest='use_chest_camera',
                        action='store_false', default=True)
    args = parser.parse_args()

    rclpy.init()
    node = XArmRecorder(
        repo_id         = args.repo_id,
        root            = args.root,
        fps             = args.fps,
        single_task     = args.single_task,
        num_episodes    = args.num_episodes,
        arm_side        = args.arm_side,
        use_wrist_camera = args.use_wrist_camera,
        use_chest_camera = args.use_chest_camera,
    )
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.cleanup()
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
