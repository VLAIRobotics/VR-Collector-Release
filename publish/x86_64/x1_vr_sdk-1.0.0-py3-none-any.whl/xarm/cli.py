#!/usr/bin/env python3
import argparse
import os
import shutil
import signal
import subprocess
import sys
import time

import yaml

_HERE      = os.path.dirname(__file__)
NODES_DIR  = os.path.join(_HERE, "ros2_nodes")
CONFIG_DIR = os.path.join(_HERE, "configs")


# ---------- helpers ----------

def _load_config(path):
    with open(os.path.expanduser(path)) as f:
        return yaml.safe_load(f)


def _node_path(name):
    return os.path.join(NODES_DIR, name)


# ---------- commands ----------

def cmd_install(args):
    script = os.path.join(_HERE, "install.sh")
    os.execvp("bash", ["bash", script])


def cmd_init(args):
    src = os.path.join(CONFIG_DIR, "default.yaml")
    dst = os.path.expanduser(args.output)
    shutil.copy(src, dst)
    print(f"Config written to: {dst}")
    print("Edit the file, then run: xarm collect --config " + dst)


def cmd_setup_can(args):
    ifaces = args.interfaces if args.interfaces else ["can2", "can3"]
    if args.config:
        cfg = _load_config(args.config)
        robot = cfg.get("robot", {})
        ifaces = [robot.get("left_can", "can2"), robot.get("right_can", "can3")]

    for iface in ifaces:
        print(f"⚙️  Configuring {iface} ...")
        subprocess.run(["sudo", "ip", "link", "set", iface, "down"],                                                                    check=True)
        subprocess.run(["sudo", "ip", "link", "set", iface, "type", "can", "bitrate", "1000000", "dbitrate", "5000000", "fd", "on"], check=True)
        subprocess.run(["sudo", "ip", "link", "set", iface, "up"],                                                                    check=True)
        print(f"✅ {iface} configured.")
    print("✅ CAN interfaces configured.")


def cmd_check(args):
    cfg   = _load_config(args.config)
    robot = cfg.get("robot", {})
    left  = robot.get("left_can",  "can2")
    right = robot.get("right_can", "can3")

    ok = True
    print("=== CAN interfaces ===")
    for iface in [left, right]:
        result = subprocess.run(["ip", "link", "show", iface],
                                capture_output=True, text=True)
        if "UP" in result.stdout:
            print(f"  ✅ {iface}: UP")
        else:
            print(f"  ❌ {iface}: NOT UP  →  run: xarm setup-can --config {args.config}")
            ok = False

    print("=== Dependencies ===")
    for pkg in ["xarm_can", "xrobotoolkit_sdk", "mink", "mujoco", "rclpy"]:
        try:
            __import__(pkg)
            print(f"  ✅ {pkg}")
        except ImportError:
            print(f"  ❌ {pkg}: not found")
            ok = False

    sys.exit(0 if ok else 1)


def cmd_collect(args):
    cfg        = _load_config(args.config)
    robot      = cfg.get("robot",      {})
    teleop     = cfg.get("teleop",     {})
    collection = cfg.get("collection", {})

    left  = robot.get("left_can",  "can2")
    right = robot.get("right_can", "can3")
    for iface in [left, right]:
        result = subprocess.run(["ip", "link", "show", iface], capture_output=True, text=True)
        if "UP" not in result.stdout:
            print(f"⚙️  CAN 接口 {iface} 未就绪，正在自动配置...")
            subprocess.run(["sudo", "ip", "link", "set", iface, "down"],                                                                    check=True)
            subprocess.run(["sudo", "ip", "link", "set", iface, "type", "can", "bitrate", "1000000", "dbitrate", "5000000", "fd", "on"], check=True)
            subprocess.run(["sudo", "ip", "link", "set", iface, "up"],                                                                    check=True)
            print(f"✅ {iface} 已配置")

    hw_cmd = [
        sys.executable, _node_path("hardware_node.py"),
        "--left-can",  robot.get("left_can",  "can2"),
        "--right-can", robot.get("right_can", "can3"),
        "--config",    args.config,
    ]

    tp_cmd = [
        sys.executable, _node_path("teleop_node.py"),
        "--filter-alpha", str(teleop.get("filter_alpha", 0.5)),
        "--scale-factor",  str(teleop.get("scale_factor",  1.0)),
        "--config",    args.config,
    ]

    repo_id = collection.get("repo_id", collection.get("task_name", "xarm/default"))
    rec_cmd = [
        sys.executable, _node_path("recorder_node.py"),
        "--repo-id",      repo_id,
        "--root",         collection.get("dataset_path",  "~/lerobot_datasets"),
        "--fps",          str(collection.get("record_rate_hz", 30)),
        "--arm-side",     collection.get("arm_side",      "dual_arm"),
        "--single-task",  collection.get("task_name",     "default_task"),
        "--num-episodes", str(collection.get("num_episodes", 50)),
    ]

    # 相机开关：缺省时胸部相机开、手腕相机关，与原有行为一致
    cameras = collection.get("cameras", {})
    if not cameras.get("chest", {}).get("enabled", True):
        rec_cmd.append("--no-chest-camera")
    if (cameras.get("wrist_right", {}).get("enabled", False) or
            cameras.get("wrist_left", {}).get("enabled", False)):
        rec_cmd.append("--use-wrist-camera")

    procs = []

    def _cleanup(_sig=None, _frame=None):
        print("\n🛑 Stopping all nodes ...")
        for p in procs:
            if p.poll() is None:
                try:
                    p.send_signal(signal.SIGINT)
                except OSError:
                    pass
        for p in procs:
            try:
                # 给 recorder 留足时间 finalize（关闭 parquet 写入器、刷出 meta/episodes、
                # 收尾视频编码），否则会留下无法加载的半成品数据集
                p.wait(timeout=60)
            except subprocess.TimeoutExpired:
                p.kill()
        print("✅ All nodes stopped.")
        sys.exit(0)

    def _wait_for_topic(topic, feeding_proc, timeout=30, interval=1):
        deadline = time.time() + timeout
        while time.time() < deadline:
            if feeding_proc.poll() is not None:
                print(f"❌ 节点意外退出（code {feeding_proc.returncode}），停止启动")
                _cleanup()
            result = subprocess.run(
                ["ros2", "topic", "list"],
                capture_output=True, text=True,
            )
            if topic in result.stdout:
                return
            time.sleep(interval)
        print(f"❌ 等待话题 {topic} 超时（{timeout}s），停止启动")
        _cleanup()

    signal.signal(signal.SIGINT,  _cleanup)
    signal.signal(signal.SIGTERM, _cleanup)

    print("🚀 [1/3] Starting hardware_node ...")
    procs.append(subprocess.Popen(hw_cmd))

    print("⏳ Waiting for /dual_xarm/joints topic ...")
    _wait_for_topic("/dual_xarm/joints", procs[0], timeout=30)

    print("🚀 [2/3] Starting teleop_node ...")
    procs.append(subprocess.Popen(tp_cmd))

    print("⏳ Waiting for /dual_xarm/action/joints_position topic ...")
    _wait_for_topic("/dual_xarm/action/joints_position", procs[1], timeout=30)

    print("🚀 [3/3] Starting recorder_node ...")
    procs.append(subprocess.Popen(rec_cmd))

    print("\n✅ All nodes running. Press Ctrl+C to stop and save.\n")

    while True:
        for p in procs:
            if p.poll() is not None:
                print(f"❌ A node exited unexpectedly (code {p.returncode}). Shutting down ...")
                _cleanup()
        time.sleep(1)


# ---------- main ----------

def main():
    parser = argparse.ArgumentParser(
        prog="xarm",
        description="XArm SDK — VR teleoperation data collection toolkit",
    )
    sub = parser.add_subparsers(dest="command", metavar="<command>")

    # xarm install
    sub.add_parser("install", help="Install runtime dependencies")

    # xarm init
    p = sub.add_parser("init", help="Generate a default config file")
    p.add_argument("--output", default="xarm_config.yaml",
                   help="Output path (default: xarm_config.yaml)")

    # xarm collect
    p = sub.add_parser("collect", help="Start full data collection pipeline")
    p.add_argument("--config", required=True, help="Path to config yaml")

    # xarm setup-can
    p = sub.add_parser("setup-can", help="Configure SocketCAN interfaces")
    p.add_argument("--config", default=None, help="Config yaml (to read CAN port names)")
    p.add_argument("--interfaces", nargs="+", metavar="IFACE",
                   help="Override CAN interfaces (e.g. --interfaces can2 can3)")

    # xarm check
    p = sub.add_parser("check", help="Check hardware and dependency status")
    p.add_argument("--config", required=True, help="Path to config yaml")

    args = parser.parse_args()

    if   args.command == "install":   cmd_install(args)
    elif args.command == "init":      cmd_init(args)
    elif args.command == "collect":   cmd_collect(args)
    elif args.command == "setup-can": cmd_setup_can(args)
    elif args.command == "check":     cmd_check(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
