import sys as _sys, os as _os, ctypes as _ctypes

_vendor = _os.path.join(_os.path.dirname(__file__), "_vendor")
_sys.path.insert(0, _vendor)

_pxrea = _os.path.join(_vendor, "libPXREARobotSDK.so")
if _os.path.exists(_pxrea):
    _ctypes.CDLL(_pxrea)

del _sys, _os, _ctypes, _vendor, _pxrea
