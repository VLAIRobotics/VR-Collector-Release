import os
import sys
# 离线数据采集：禁止 lerobot/huggingface_hub 访问网络（必须在导入 lerobot 之前设置）
os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
# 把 xarm_sdk/ 加进搜索路径，使 xarm 包可被导入（无论从哪个目录启动）
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

import argparse
import yaml
import rclpy
from xarm._collection.recorder import XArmRecorder


# config 里的相机键 -> LeRobot 特征键
CFG_KEY_TO_FEATURE = {
    'chest':       'observation.images.cam_chest',
    'wrist_left':  'observation.images.cam_wrist_left',
    'wrist_right': 'observation.images.cam_wrist_right',
}
# 无 config 时（standalone + flag）使用的缺省话题，统一两层命名空间 + image_raw
DEFAULT_CAM_TOPICS = {
    'observation.images.cam_chest':       '/cam_chest/cam_chest/color/image_raw',
    'observation.images.cam_wrist_left':  '/cam_wrist_left/cam_wrist_left/color/image_raw',
    'observation.images.cam_wrist_right': '/cam_wrist_right/cam_wrist_right/color/image_raw',
}


def _load_config(path):
    with open(os.path.expanduser(path)) as f:
        return yaml.safe_load(f)


def _build_cameras(args):
    """返回 {特征键 -> 话题}，仅含已启用的相机。
    有 --config 时完全以 config 的 cameras.*.{topic,enabled} 为准；
    否则回退到 --use-wrist-camera / --no-chest-camera + 缺省话题。
    """
    cameras = {}
    if args.config:
        cams_cfg = _load_config(args.config).get("collection", {}).get("cameras", {})
        # 固定顺序，保证数据集特征顺序稳定
        for cfg_key in ("chest", "wrist_left", "wrist_right"):
            cam = cams_cfg.get(cfg_key, {})
            # 胸部相机缺省开，腕部缺省关
            if cam.get("enabled", cfg_key == "chest"):
                feature = CFG_KEY_TO_FEATURE[cfg_key]
                cameras[feature] = cam.get("topic", DEFAULT_CAM_TOPICS[feature])
    else:
        if args.use_chest_camera:
            k = 'observation.images.cam_chest'
            cameras[k] = DEFAULT_CAM_TOPICS[k]
        if args.use_wrist_camera:
            for k in ('observation.images.cam_wrist_left',
                      'observation.images.cam_wrist_right'):
                cameras[k] = DEFAULT_CAM_TOPICS[k]
    return cameras


def main():
    parser = argparse.ArgumentParser(description='XArm LeRobot Data Collector')
    parser.add_argument('--repo-id',           type=str, required=True)
    parser.add_argument('--root',              type=str, default='~/lerobot_datasets')
    parser.add_argument('--fps',               type=int, default=30)
    parser.add_argument('--arm-side',          type=str, default='dual_arm',
                        choices=['right_arm', 'left_arm', 'dual_arm'])
    parser.add_argument('--single-task',       type=str, default='default_task')
    parser.add_argument('--num-episodes',      type=int, default=50)
    parser.add_argument('--config',            type=str, default=None,
                        help='Config yaml; 提供时相机由 collection.cameras 决定')
    # 无 --config 时的回退开关
    parser.add_argument('--use-wrist-camera',  action='store_true', default=False)
    parser.add_argument('--no-chest-camera',   dest='use_chest_camera',
                        action='store_false', default=True)
    args = parser.parse_args()

    cameras = _build_cameras(args)

    rclpy.init()
    node = XArmRecorder(
        repo_id      = args.repo_id,
        root         = args.root,
        fps          = args.fps,
        single_task  = args.single_task,
        num_episodes = args.num_episodes,
        arm_side     = args.arm_side,
        cameras      = cameras,
    )
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.cleanup()
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
